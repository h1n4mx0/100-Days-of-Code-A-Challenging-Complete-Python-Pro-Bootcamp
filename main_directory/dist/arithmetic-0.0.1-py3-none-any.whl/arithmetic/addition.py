# This module is all about addition
# print("This is addition module")
def add(n1, n2):
    print("n1 and n2 for addition are: ", n1,'and', n2)
    add = n1 + n2
    return add
