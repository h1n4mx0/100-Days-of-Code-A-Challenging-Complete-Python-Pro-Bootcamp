# Multiplication and Power Functions
# Multiplication Function
def mul(n1, n2):
    mul = n1 * n2
    print('Multiplication of two numbers n1 and n2 is :', mul)
    return mul

# Power Function
def power(n1, n2):
    power= n1 ** n2
    print('Power of two numbers n1 and n2 is :', power)
    return power
