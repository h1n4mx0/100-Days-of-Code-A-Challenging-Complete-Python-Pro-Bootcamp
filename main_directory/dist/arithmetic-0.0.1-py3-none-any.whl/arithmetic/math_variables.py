# Math Variables and Constants
import math

pi = math.pi
e = math.e
tau = math.tau
