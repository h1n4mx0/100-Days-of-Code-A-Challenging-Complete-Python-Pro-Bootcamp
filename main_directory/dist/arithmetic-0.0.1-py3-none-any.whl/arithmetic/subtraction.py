# This module is all about subtraction
# print("This is subtraction module")
def sub(n1, n2):
    print("n1 and n2 for subtraction are: ", n1,'and', n2)
    sub = n1 - n2
    return sub
